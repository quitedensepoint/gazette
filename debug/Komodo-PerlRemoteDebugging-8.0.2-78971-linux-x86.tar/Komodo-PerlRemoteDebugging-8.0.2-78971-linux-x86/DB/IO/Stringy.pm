package DB::IO::Stringy;

use vars qw($VERSION);
$VERSION = substr q$Revision: 2.109 $, 10;
